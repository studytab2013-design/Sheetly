SHEETLY MAX — STATIC WEBSITE

1. Upload index.html to a static website host.
2. No database or login system is required.
3. Each visitor's workbook is saved in that visitor's own browser storage.
4. Use Save backup regularly to download a JSON backup.
5. Restore backup imports a previously downloaded Sheetly JSON backup.

IMPORTANT:
Browser storage is local to one browser/device. It does not sync workbooks
between different devices or visitors. Clearing browser site data can erase
the local copy, so keep backups.
